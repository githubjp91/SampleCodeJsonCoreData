

import UIKit

struct jsonStruct : Decodable
{
    let name : String
    let region : String
    let capital : String
    let subregion : String
    let nativeName : String
}

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var isSync:Bool = false
    
    var aryData = [jsonStruct]()
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // print(DataBase.share.fetchRecords())
        
        if isSync == false
        {
            fetchDataAPI()

        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return DataBase.share.fetchRecords().count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let details:detailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "detailsViewController")as! detailsViewController
        
        var dart = DataBase.share.fetchRecords()
        
        details.strCapital = dart[indexPath.row].capital
        
        details.strsuRegion = dart[indexPath.row].subregion
        
        details.strNativeName = dart[indexPath.row].nativeName
        
        self.navigationController?.pushViewController(details, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell")as! cusTableViewCell
        
        //        cell.lblName.text = "Name:\(aryData[indexPath.row].name)"
        //
        //        cell.lblregion.text = "region:\(aryData[indexPath.row].region)"
        
        var dart = DataBase.share.fetchRecords()
        
        cell.lblName.text = dart[indexPath.row].name
        cell.lblregion.text = dart[indexPath.row].region
        
        
        return cell
    }
    
    func fetchDataAPI()
    {
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do{
                if error == nil
                {
//                    self.aryData = try JSONDecoder().decode([jsonStruct].self, from: data!)
                    DataBase.share.insert(arr: self.aryData)
                    print(self.aryData)
              // print(self.arrayWithJSONData)
                    
                    for FecthJsonData in self.aryData
                    {
                        
                        DispatchQueue.main.async {
                            self.tblView.reloadData()
                        }
                    }
                    self.isSync = true

                    DataBase.share.fetchRecords()
                }
            }
            catch
            {
                print("Not Data Available")
            }
        }.resume()
        
    }
        }

