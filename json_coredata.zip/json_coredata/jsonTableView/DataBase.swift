
import Foundation
import UIKit
import CoreData

class DataBase {

    static var share:DataBase = DataBase()
    
    func fetchRecords() -> [jsonStruct]
    {
         var user = [jsonStruct]()
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let manageContext:NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Users")
        //        fetchRequest.predicate = NSPredicate.init(format: " Name = 'ABC' ")
        //        fetchRequest.sortDescriptors = [NSSortDescriptor.init(key: "id", ascending: false)]
        do{
            if let users = try manageContext.fetch(fetchRequest) as? [NSManagedObject]
            {
                for userhh in users
                {
                    user.append(jsonStruct(name: userhh.value(forKey: "Name") as! String,
                    region: userhh.value(forKey: "region") as! String,
                    capital: userhh.value(forKey: "capital") as! String,
                    subregion: userhh.value(forKey: "subregion") as! String,
                    nativeName: userhh.value(forKey: "nativeName") as! String))
                    
                   // print(userhh.value(forKey: "Name"))
                    }
            }
            else
            {
                print("No record found")
            }
        }
        catch
        {
            print(error.localizedDescription)
        }
        return user
    }
    
    func insert(arr:[jsonStruct]) {
        
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let manageContext:NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        
        for i in arr {
            let entity = NSEntityDescription.insertNewObject(forEntityName: "Users", into: manageContext)
            
            entity.setValue(i.name, forKey: "name")
            entity.setValue(i.capital, forKey: "capital")
            entity.setValue(i.nativeName, forKey: "nativeName")
            entity.setValue(i.region, forKey: "region")
            entity.setValue(i.subregion, forKey: "subregion")
            
            do
            {
            try manageContext.save()
            }
            catch{
                print(error.localizedDescription)
            }
        }
    }
    
//    func addRecords()
//    {
//        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
//        let manageContext:NSManagedObjectContext = appDelegate.persistentContainer.viewContext
//
//        let entity = NSEntityDescription.insertNewObject(forEntityName: "Users", into: manageContext)
//
//        entity.setValue(Int16(1), forKey: "id")
//        entity.setValue("ABC", forKey: "Name")
//
//        do
//        {
//            try manageContext.save()
//
//
//            //            let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: "Users")
//            //
//            //            try manageContext.fetch(request) as? NSManagedObject
//
//
//        }
//        catch
//        {
//            print(error.localizedDescription)
//        }
//
//
//
//    }
    
}

