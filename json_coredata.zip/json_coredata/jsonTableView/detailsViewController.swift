

import UIKit

class detailsViewController: UIViewController {
    
    @IBOutlet weak var lblView: UIView!
    @IBOutlet weak var lblCapital: UILabel!
    
    @IBOutlet weak var lblSubRegion: UILabel!
    @IBOutlet weak var lblnativeName: UILabel!
    
    var strCapital = ""
    var strsuRegion = ""
    var strNativeName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblView.layer.cornerRadius = 20
        
        lblCapital.text = strCapital
        lblSubRegion.text = strsuRegion
        lblnativeName.text = strNativeName
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}
